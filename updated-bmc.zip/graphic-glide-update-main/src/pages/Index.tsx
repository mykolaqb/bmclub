import { motion, useScroll, useTransform, type Variants } from "framer-motion";
import { useRef } from "react";
import { Linkedin, Search, Mic, Handshake, Zap, ArrowUpRight } from "lucide-react";

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

const stagger: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08 } },
};

const BMLogo = ({ className = "", size = 32, delay = 0 }: { className?: string; size?: number; delay?: number }) => (
  <motion.img
    src="/bm-logo.png"
    alt="BM Club Logo"
    width={size}
    height={size}
    initial={{ opacity: 0, scale: 0.6 }}
    animate={{ opacity: 1, scale: 1 }}
    transition={{ duration: 1.2, delay, ease: "easeOut" }}
    className={`object-contain ${className}`}
    style={{ background: "transparent" }}
  />
);

const SectionLabel = ({ children }: { children: React.ReactNode }) => (
  <motion.p
    variants={fadeUp}
    className="mb-3 text-[10px] font-semibold uppercase tracking-[0.25em] text-accent"
  >
    {children}
  </motion.p>
);

const Index = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const diamondY = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const diamondRotate = useTransform(scrollYProgress, [0, 1], [45, 90]);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* NAV */}
      <nav className="sticky top-0 z-50 border-b border-border/60 bg-background/75 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <a href="#top" className="flex items-center gap-2.5">
            <img src="/bm-logo.png" alt="BM Club Logo" className="h-8 w-8 object-contain" />
            <span className="font-display text-sm tracking-wider text-foreground">BM CLUB</span>
          </a>
          <a
            href="https://www.linkedin.com/in/business-management-club-112509400"
            target="_blank"
            rel="noopener noreferrer"
            className="story-link text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground hover:text-accent"
          >
            LinkedIn
          </a>
        </div>
      </nav>

      {/* HERO */}
      <header id="top" ref={heroRef} className="relative overflow-hidden border-b border-border/60">
        <div className="absolute inset-0 bg-gradient-hero" aria-hidden />
        <div className="absolute inset-0 bg-grid opacity-40" aria-hidden />

        {/* Floating brand diamonds */}
        <motion.div
          style={{ y: diamondY, rotate: diamondRotate }}
          className="pointer-events-none absolute -right-24 top-10 h-[420px] w-[420px] diamond-outline shadow-elegant md:right-[-80px]"
          aria-hidden
        />
        <motion.div
          style={{ y: useTransform(scrollYProgress, [0, 1], [0, -120]) }}
          className="pointer-events-none absolute -left-20 bottom-[-60px] h-40 w-40 rotate-45 border border-accent/40 bg-accent/5 animate-float-slow"
          aria-hidden
        />

        <div className="relative mx-auto max-w-6xl px-6 pt-28 pb-32 md:pt-36 md:pb-40">
          <motion.div initial="hidden" animate="show" variants={stagger} className="max-w-3xl">
            <motion.div variants={fadeUp} className="mb-8 inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/5 px-4 py-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-accent animate-pulse" />
              <span className="text-[11px] font-semibold uppercase tracking-[0.2em] text-accent">
                Faculty of Management · University of Łódź
              </span>
            </motion.div>

            <motion.h1
              variants={fadeUp}
              className="font-display text-5xl uppercase leading-[0.95] tracking-tight text-foreground md:text-7xl lg:text-[5.5rem]"
            >
              <span className="text-gradient-gold">Business</span>
              <br />
              Management
              <br />
              Club
            </motion.h1>

            <motion.p variants={fadeUp} className="mt-8 max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg">
              A student club at the Faculty of Management that studies companies through three perspectives — company, market, and business model — and invites the practitioners behind them to speak.
            </motion.p>

            <motion.div variants={fadeUp} className="mt-12 flex flex-wrap gap-x-8 gap-y-3">
              {["Room 306 · ul. Jana Matejki 22/26"].map((t) => (
                <span key={t} className="flex items-center gap-2.5 text-sm text-muted-foreground">
                  <span className="h-1 w-1 rounded-full bg-accent" />
                  {t}
                </span>
              ))}
            </motion.div>
          </motion.div>
        </div>

        {/* Bottom marquee strip */}
        <div className="relative border-t border-border/60 bg-surface/40 py-3">
          <div className="flex items-center gap-12 overflow-hidden whitespace-nowrap text-xs uppercase tracking-[0.3em] text-muted-foreground">
            <div className="flex animate-[shimmer_25s_linear_infinite] gap-12">
              {Array.from({ length: 6 }).map((_, i) => (
                <span key={i} className="flex items-center gap-12">
                  <span>Research</span><span className="text-accent">◆</span>
                  <span>Present</span><span className="text-accent">◆</span>
                  <span>Discuss</span><span className="text-accent">◆</span>
                  <span>Decide</span><span className="text-accent">◆</span>
                </span>
              ))}
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6">
        {/* WHAT WE DO */}
        <Section>
          <SectionLabel>What we do</SectionLabel>
          <SectionTitle>
            We study companies and talk<br />to the people behind them
          </SectionTitle>
          <SectionLead>
            We invite people from businesses to join our meetings and present them a picture of reality that we can build after doing research. Then we create stories in teams that cover three perspectives: Company, Market and Business model. This is followed by Q&A sessions and discussion.
          </SectionLead>
          <motion.div variants={stagger} className="mt-12 grid gap-5 md:grid-cols-3">
            {[
              { t: "Company Story", d: "What the company does, how it operates, and how it grew." },
              { t: "Market Story", d: "The market the company operates in, its competitors, and how it positions itself." },
              { t: "Business Model Story", d: "How value is created and delivered." },
            ].map((c, i) => (
              <motion.div
                key={c.t}
                variants={fadeUp}
                whileHover={{ y: -6 }}
                transition={{ type: "spring", stiffness: 300, damping: 22 }}
                className="group relative overflow-hidden rounded-xl border border-border bg-card p-7"
              >
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-accent via-accent/40 to-transparent" />
                <div className="mb-5 flex items-center gap-3">
                  <span className="diamond-outline h-3 w-3 rotate-45" />
                  <span className="font-display text-xs uppercase tracking-widest text-accent">0{i + 1}</span>
                </div>
                <h3 className="mb-3 font-display text-lg uppercase text-foreground">{c.t}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{c.d}</p>
              </motion.div>
            ))}
          </motion.div>
        </Section>

        {/* MEETING FORMAT */}
        <Section>
          <SectionLabel>Meeting format</SectionLabel>
          <SectionTitle>The meeting is a space for presenting results</SectionTitle>
          <SectionLead>All research and preparation takes place before the session. Time at the meeting is used for presenting, asking questions, and hearing from the guest.</SectionLead>
          <motion.div variants={stagger} className="mt-12 grid gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-2">
            {[
              { n: "01", t: "Teams prepare their stories", d: "Each team researches and builds their part of the story and meeting kit parts before the meeting. All materials are uploaded to Miro at least 24 hours in advance." },
              { n: "02", t: "Stories are presented at the meeting", d: "Each team presents their story to the full group. Three stories combine into one picture of the company." },
              { n: "03", t: "A practitioner joins as a guest", d: "We invite a practitioner connected to the company being studied. They respond to the stories, add context from their experience, and answer questions prepared in advance by the group." },
              { n: "04", t: "Afterparty", d: "After meetings with guests, the session closes with one of the club's business games or an open discussion." },
            ].map((s) => (
              <motion.div key={s.n} variants={fadeUp} className="group relative bg-card p-7 transition-colors hover:bg-surface">
                <div className="flex items-start gap-5">
                  <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full border border-accent/40 bg-accent/5 font-display text-sm text-accent transition-all group-hover:bg-accent group-hover:text-accent-foreground">
                    {s.n}
                  </div>
                  <div>
                    <h3 className="mb-1.5 font-display text-base uppercase tracking-wide text-foreground">{s.t}</h3>
                    <p className="text-sm leading-relaxed text-muted-foreground">{s.d}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </Section>

        {/* GUEST SPEAKERS */}
        <Section>
          <SectionLabel>Guest speakers</SectionLabel>
          <SectionTitle>
            Practitioners from<br />the companies we study
          </SectionTitle>
          <SectionLead>Our club invites guests from the companies and then does research covering them. The criterion is that the guest is a working practitioner — someone with direct experience inside the business. Past and upcoming guests:</SectionLead>
          <motion.div variants={stagger} className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {[
              "Lark Business Consulting",
              "Hexagon AB",
              "Amazon",
              "Strategyzer",
              "Expertunity",
              "Podkawa",
              "NAC",
            ].map((company) => (
              <motion.div
                key={company}
                variants={fadeUp}
                whileHover={{ y: -4, borderColor: "hsl(var(--accent) / 0.5)" }}
                className="rounded-lg border border-border bg-card p-5"
              >
                <div className="flex items-center gap-2">
                  <span className="diamond-outline h-2 w-2 rotate-45" />
                  <div className="text-sm font-semibold text-foreground">{company}</div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </Section>

        {/* AFTERPARTY */}
        <Section>
          <SectionLabel>Afterparty activities</SectionLabel>
          <SectionTitle>
            After the meeting with the guest,<br />participants can stay to play games together
          </SectionTitle>
          <SectionLead>After meetings with guests the club runs one of three business games.</SectionLead>
          <motion.div variants={stagger} className="mt-12 grid gap-5 md:grid-cols-3">
            {[
              { tag: "Activity 01", t: "Pitch Game", d: "One person draws a startup card with a short description of a business idea. They have 3 minutes to prepare and then pitch the startup to three investors. Each investor holds a challenge card describing a specific business bottleneck or constraint. After the pitch investors present their challenges one at a time; the pitcher responds to each. After all challenges, each investor states a verdict — In or Out — with reasoning." },
              { tag: "Activity 02", t: "Decision Room", d: "One participant prepares a real business case in advance — a situation in which a company faced a high-stakes decision. Participants are divided into teams and act as the company's executive group. Each team discusses the situation and commits to a decision. Teams present their decisions one by one. The host then reveals what the company actually decided and what the outcome was." },
              { tag: "Activity 03", t: "YC Partner Simulator", d: "We watch real Y Combinator application pitch videos, then decide to Accept or Reject each startup — just like a Y Combinator partner would. After a decision was made, we can see whether the actual YC partners had the same decision." },
            ].map((c) => (
              <motion.div
                key={c.t}
                variants={fadeUp}
                whileHover={{ y: -6 }}
                className="group relative overflow-hidden rounded-xl border border-border bg-card p-7"
              >
                <div className="absolute -right-10 -top-10 h-32 w-32 rotate-45 border border-primary-glow/30 bg-primary/20 transition-transform duration-500 group-hover:rotate-[60deg]" />
                <div className="relative">
                  <span className="mb-4 inline-block rounded-full border border-primary-glow/40 bg-primary/20 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-primary-glow">
                    {c.tag}
                  </span>
                  <h3 className="mb-3 font-display text-lg uppercase text-foreground">{c.t}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">{c.d}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </Section>

        {/* STANDARDS */}
        <Section>
          <SectionLabel>Standards</SectionLabel>
          <SectionTitle>How the club operates</SectionTitle>
          <motion.div variants={stagger} className="mt-12 space-y-3">
            {[
              "Meetings are for sharing results - all work takes place before the meeting.",
              "Members choose tasks for themselves, not assigned.",
              "Communication is in factual terms.",
              "All contributions are uploaded to Miro at least 24 hours before the meeting.",
              "Members arrive on time and bring value.",
              "Attendance is recorded by 10:00 on meeting day.",
            ].map((s) => (
              <motion.div
                key={s}
                variants={fadeUp}
                className="group flex items-center gap-4 rounded-lg border border-border bg-card px-6 py-5 transition-all hover:border-accent/40 hover:bg-surface"
              >
                <span className="diamond-outline h-2.5 w-2.5 flex-shrink-0 rotate-45 transition-transform group-hover:rotate-[90deg]" />
                <p className="text-sm text-foreground md:text-base">{s}</p>
              </motion.div>
            ))}
          </motion.div>
        </Section>

        {/* WHAT YOU GAIN */}
        <Section>
          <SectionLabel>What you can gain</SectionLabel>
          <SectionTitle>
            Skills you<br />can build
          </SectionTitle>
          <motion.div variants={stagger} className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { Icon: Search, t: "Business Analysis", d: "Researching and structuring materials covering businesses from different perspectives." },
              { Icon: Mic, t: "Presenting to an Audience", d: "Delivering stories to peers and business practitioners in a live setting." },
              { Icon: Handshake, t: "Professional Contact", d: "Direct conversation with practitioners in a group format." },
              { Icon: Zap, t: "Decision-Making", d: "Working through business situations under time constraints in the Decision Room format." },
            ].map(({ Icon, t, d }) => (
              <motion.div
                key={t}
                variants={fadeUp}
                whileHover={{ y: -6 }}
                className="rounded-xl border border-border bg-card p-6"
              >
                <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-lg bg-gradient-navy shadow-elegant">
                  <Icon className="h-5 w-5 text-accent-glow" strokeWidth={1.6} />
                </div>
                <h3 className="mb-2 font-display text-sm uppercase tracking-wide text-foreground">{t}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{d}</p>
              </motion.div>
            ))}
          </motion.div>
        </Section>

        {/* CTA */}
        <motion.section
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.3 }}
          variants={stagger}
          className="relative my-16 overflow-hidden rounded-2xl border border-border bg-gradient-navy p-10 md:p-16"
        >
          <div className="absolute -right-20 -top-20 h-80 w-80 rotate-45 border border-accent/40 bg-primary/40 animate-diamond-spin" aria-hidden />
          <div className="absolute -left-10 -bottom-10 h-40 w-40 rotate-45 border border-accent/30 bg-primary-glow/20 animate-float-slow" aria-hidden />
          <div className="relative max-w-2xl">
            <motion.p variants={fadeUp} className="mb-3 text-[10px] font-semibold uppercase tracking-[0.25em] text-accent-glow">
              Join us
            </motion.p>
            <motion.h2 variants={fadeUp} className="font-display text-4xl uppercase leading-[1] tracking-tight text-primary-foreground md:text-6xl">
              Follow the club<br />on <span className="text-gradient-gold">LinkedIn</span>
            </motion.h2>
            <motion.p variants={fadeUp} className="mt-6 max-w-lg text-base leading-relaxed text-primary-foreground/75">
              Meeting announcements, and stories from the club are posted on our LinkedIn page.
            </motion.p>
            <motion.div variants={fadeUp} className="mt-10 flex flex-col items-start gap-4">
              <a
                href="https://www.linkedin.com/in/business-management-club-112509400"
                target="_blank"
                rel="noopener noreferrer"
                className="group inline-flex items-center gap-3 rounded-lg bg-gradient-gold px-7 py-4 text-sm font-semibold text-accent-foreground shadow-gold transition-transform hover:scale-[1.02]"
              >
                <Linkedin className="h-4 w-4" />
                LinkedIn — Business Management Club
                <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>
            </motion.div>
          </div>
        </motion.section>
      </main>

      {/* FOOTER */}
      <footer className="border-t border-border bg-surface/40">
        <div className="mx-auto flex max-w-6xl flex-col items-center gap-3 px-6 py-12 text-center">
          <div className="flex items-center gap-2.5">
            <img src="/bm-logo.png" alt="BM Club Logo" className="h-8 w-8 object-contain" />
            <span className="font-display text-sm tracking-wider text-accent">BM CLUB</span>
          </div>
          <p className="text-xs text-muted-foreground">
            Business Management Club · Faculty of Management · University of Łódź
          </p>
          <p className="text-xs text-muted-foreground">ul. Jana Matejki 22/26, room 306</p>
        </div>
      </footer>
    </div>
  );
};

/* ---------- Reusable section wrapper ---------- */
const Section = ({ children }: { children: React.ReactNode }) => (
  <motion.section
    initial="hidden"
    whileInView="show"
    viewport={{ once: true, amount: 0.2 }}
    variants={stagger}
    className="border-b border-border/60 py-24 md:py-28"
  >
    {children}
  </motion.section>
);

const SectionTitle = ({ children }: { children: React.ReactNode }) => (
  <motion.h2
    variants={fadeUp}
    className="font-display text-3xl uppercase leading-[1.05] tracking-tight text-foreground md:text-5xl"
  >
    {children}
  </motion.h2>
);

const SectionLead = ({ children }: { children: React.ReactNode }) => (
  <motion.p variants={fadeUp} className="mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground">
    {children}
  </motion.p>
);

export default Index;
